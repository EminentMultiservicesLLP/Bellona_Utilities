import requests
import os
from dotenv import load_dotenv, dotenv_values 
import JWTToken, DBOperations
from datetime import datetime, timedelta

load_dotenv() 
def fetch_data(api_url, params = None):
    token = JWTToken.GetToken()
    api_key = os.getenv("api_key")

    headers = {
        'x-api-key': api_key,
        'x-api-token': token
    }

    if params == None :
        response = requests.get(api_url, headers=headers)
    else:
        response = requests.get(api_url, params=params, headers=headers)
    response.raise_for_status()
    return response.json()

# Step 2: Read data (array of JSON or single JSON)
def read_data(data):
    if isinstance(data, list):
        return data
    else:
        return [data]


def GetData_RistaAPI(apiUrl,params=None):
    max_retries = 3
    apiData = None
    for attempt in range(max_retries):
        try:
            apiData = fetch_data(apiUrl, params)
            #apiData = read_data(data)
            break  # Exit the loop if successful
        except Exception as e:
            print(f"Attempt {attempt+1} failed: {e}")
            if attempt < max_retries - 1:
                print("Retrying...")
            else:
                print("Max retries exceeded.")
                raise  # Optionally raise the exception after retries
    return apiData

# Main function to run the steps
def main():
    
    branches = GetData_RistaAPI(os.getenv("branch_list_url"))
    outlet_list = DBOperations.Get_OutletList()

    today = datetime.today()
    no_of_days = 1

    try:
        no_of_days  = int(os.getenv("data_pull_number_of_days"))
    except:
        no_of_days =1

    for i in range(no_of_days):
        day = today - timedelta(days=i+1)
        formatted_date = day.strftime('%Y-%m-%d')
        for outlet in outlet_list:
            if outlet.OutletCode in {branch["branchCode"] for branch in branches}:
                params = {
                    'branch': outlet.OutletCode,
                    'period': formatted_date
                }
                #data_sales_summary = fetch_data(os.getenv("sales_summary_url"), params)
                data_sales_summary = GetData_RistaAPI(os.getenv("sales_summary_url"), params)
                
                sale_types = ['Food Sale', 'Beverage Sale', 'Wine Sale', 'Beer Sale', 'Liquor Sale', 'Tobacco Sale']
                salesDineIn = {sale: sum(channel['amount'] for account in data_sales_summary['accountsWiseChannels'] if account['account'] == sale for channel in account['channels']  if channel['name'].startswith('Dinein_')) for sale in sale_types}
                #salesTakeaway = sum(channel['amount'] for account in data_sales_summary['accountsWiseChannels'] for channel in account['channels'] if not channel['name'].startswith('Dinein_'))

                Salefood, SaleBeverage, SaleWine, saleBeer, SaleLiquor, SaleTobacco = salesDineIn['Food Sale'], salesDineIn['Beverage Sale'], salesDineIn['Wine Sale'], salesDineIn['Beer Sale'], salesDineIn['Liquor Sale'], salesDineIn['Tobacco Sale']
                total_gross_amount = sum(item['itemTotalgrossAmount'] for item in data_sales_summary['items'])
                
                salesTakeaway = sum(channel['netSaleAmount'] for channel in data_sales_summary['channelSummary'] if not channel['name'].startswith('Dinein_'))
                SaleDinnerDinein = sum(channel['netSaleAmount'] for channel in data_sales_summary['channelSummary'] if channel['name'].startswith('Dinein_'))
                TotalNoOfBills  =  sum(channel['noOfSales'] for channel in data_sales_summary['channelSummary'])
                GuestCountDinner  =  sum(channel['paxCount'] for channel in data_sales_summary['channelSummary'] if channel['name'].startswith('Dinein_'))

                column_mapping = {
                    'OutletID' : outlet.OutletID,
                    'DSREntryDate' : formatted_date,
                    'SaleLunchDinein' : 0,
                    'SaleEveningDinein' :0 ,
                    'SaleDinnerDinein':SaleDinnerDinein,
                    'SaleTakeAway' : salesTakeaway, 
                    'SaleFood' : Salefood, 
                    'SaleBeverage' : SaleBeverage,
                    'SaleWine' : SaleWine, 
                    'SaleBeer' : saleBeer, 
                    'SaleLiquor' : SaleLiquor,
                    'SaleTobacco' : SaleTobacco,
                    'SaleOther' : 0,
                    'ItemsPerBill' :0 ,
                    'TotalNoOfBills' :TotalNoOfBills ,
                    'CTCSalary' : 0,
                    'ServiceCharge' :0 ,
                    'GuestCountLunch' : 0,
                    'GuestCountEvening' :0 ,
                    'GuestCountDinner' : GuestCountDinner,
                    'IsActive' : 1,
                    'CashCollected' :total_gross_amount ,
                    'CashStatus' :0 
                }
                result = DBOperations.Excute_SQL(column_mapping, 'dbo.Transaction_Daily_Sales', True, {"OutletID","DSREntryDate" },True)
                if result > 0:
                    print("Success insert new entry in DSR for Outlet :" + outlet.OutletCode + " and Sale Date:" + formatted_date)
                else:
                    print("Failed to insert new entry in DSR for Outlet :" + outlet.OutletCode+ " and Sale Date:" + formatted_date)

# Ensure the script runs when executed
if __name__ == "__main__":
    main()


# Salefood = sum(channel['amount'] for account in data_sales_summary['accountsWiseChannels'] if account['account'] == 'Food Sale' for channel in account['channels'])
# SaleBeverage = sum(channel['amount'] for account in data_sales_summary['accountsWiseChannels'] if account['account'] == 'Beverage Sale' for channel in account['channels'])
# SaleLiquor = sum(channel['amount'] for account in data_sales_summary['accountsWiseChannels'] if account['account'] == 'Liquor Sale' for channel in account['channels'])
# SaleWine = sum(channel['amount'] for account in data_sales_summary['accountsWiseChannels'] if account['account'] == 'Wine Sale' for channel in account['channels'])


#upsert_data_to_mssql(mapped_data, table_name, conn_params, id_column)

# insert_sql = f"""INSERT INTO dbo.Transaction_Daily_Sales 
#             (OutletID, DSREntryDate, SaleLunchDinein, SaleEveningDinein, SaleDinnerDinein,/* TotalSaleDinein, */
#             SaleTakeAway, SaleFood, SaleBeverage, SaleWine, SaleBeer, SaleLiquor, SaleTobacco, SaleOther, 
#             ItemsPerBill, TotalNoOfBills, CTCSalary, ServiceCharge, GuestCountLunch, GuestCountEvening, GuestCountDinner, IsActive,CashCollected,CashStatus)
#             SELECT """
# value_sql = f"""{outlet.OutletID},'{formatted_date}',0,0,{SaleDinnerDinein},
#             {salesTakeaway}, {Salefood}, {SaleBeverage},{SaleWine}, {saleBeer}, {SaleLiquor}, {SaleTobacco}, 0,
#             0,{TotalNoOfBills},0,0,0,0,{GuestCountDinner},1,{total_gross_amount},0"""

